// DOM Elements
// const themeBtn = document.getElementById('theme-btn');
const themeIcon = document.getElementById('theme-icon');
const themeList = document.getElementById('theme-list');
// const themeText = document.getElementById('theme-text');
const closeBtn = document.getElementById('close-btn');
const postContainer = document.getElementById('post-container'); // To Hide Container
const postText = document.getElementById('post-text');
const confirmationModal = document.getElementById('confirmation-modal');
const overlay = document.getElementById('overlay');
const confirmExitBtn = document.getElementById('confirm-exit');
const cancelExitBtn = document.getElementById('cancel-exit');
const emojiBtn = document.getElementById('emoji-btn');
const emojiPicker = document.getElementById('emoji-picker');
const imageUploadBtn = document.getElementById('image-upload-btn');
const locationBtn = document.getElementById('location-btn');
const printMyLocation = document.querySelector('.my-location');
const postBtn = document.querySelector('.post-btn');
const fontColor = document.querySelector('.fa-font');
const backGroundColor = document.querySelector('.fa-fill-drip');
const textAlign = document.querySelectorAll('.align-text i');

// Track changes in the textarea
let hasChanges = false;

// Event Listener for Textarea Input
postText.addEventListener('input', () => {
  hasChanges = postText.value.trim() !== "";
  togglePostButton();
});

// Toggle Post Button State
function togglePostButton() {
  if (postText.value.trim() !== "") {
    postBtn.disabled = false;
    postBtn.style.cursor = "pointer";
    postBtn.style.backgroundColor = "#0866ff";
    postBtn.style.color = "#fff";
  } else {
    postBtn.disabled = true;
    postBtn.style.cursor = "not-allowed";
    postBtn.style.backgroundColor = "#3b3d3e";
    postBtn.style.color = "#989ca0";
  }
}

// Close Post Container
function closePostContainer() {
  postContainer.style.display = "none";
  confirmationModal.style.display = "none";
  overlay.style.display = "none";
}

// Event Listener for Close Button
closeBtn.addEventListener('click', () => {
  if (hasChanges) {
    confirmationModal.style.display = "block";
    overlay.style.display = "block";
  } else {
    closePostContainer();
  }
});

// Event Listener for Confirm Exit Button
confirmExitBtn.addEventListener('click', () => {
  closePostContainer();
});

// Event Listener for Cancel Exit Button
cancelExitBtn.addEventListener('click', () => {
  confirmationModal.style.display = "none";
  overlay.style.display = "none";
});

// Theme List Toggle
themeIcon.addEventListener('click', () => {
  const isHidden = getComputedStyle(themeList).display === 'none';
  themeList.style.display = isHidden ? 'flex' : 'none';
  themeIcon.classList.toggle('hidden', isHidden);
});

// Change Textarea Background Color
const colors = ['transparent', 'green', 'yellow', '#c600ff', '#e2013b', '#111111',
                'linear-gradient(45deg, #e80555 ,#402fbb)', 'linear-gradient(45deg,#6c3edd , #ed36f9)', 'linear-gradient(90deg, #b824ae , #fccf42)'];
const themeListItems = document.querySelectorAll('#theme-list li');

themeListItems.forEach((item, index) => {
  item.addEventListener('click', () => {
    postText.style.background = colors[index];
    item.style.backGroundColor = '#1E90FF';
  });
});

// Emoji Picker
emojiBtn.addEventListener('click', () => {
  emojiPicker.classList.toggle('hidden');
});

emojiPicker.addEventListener('emoji-click', (event) => {
  postText.value += event.detail.unicode;
  emojiPicker.classList.add('hidden');
});

// Uploading Image
const imageInput = document.createElement('input');
imageInput.type = 'file';
imageInput.accept = 'image/*';
imageInput.style.display = 'none';

imageUploadBtn.addEventListener('click', () => {
  imageInput.click();
});

imageInput.addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = document.createElement('img');
      img.src = e.target.result;
      img.classList.add('uploaded-img');
      postText.insertAdjacentElement('afterend', img);
    };
    reader.readAsDataURL(file);
  }
});

// Get User Location and Convert to Address using OpenStreetMap

// التحقق مما إذا كان المستخدم قد منح الإذن مسبقًا
const locationGranted = localStorage.getItem("locationGranted");

locationBtn.addEventListener("click", () => {
  if (!locationGranted) {
    // إذا لم يُمنح الإذن مسبقًا، اطلب الموقع
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        // تخزين الموافقة على منح الإذن في localStorage
        localStorage.setItem("locationGranted", "true");

        // استخراج الإحداثيات
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;

        // استخدام Nominatim لتحويل الإحداثيات إلى اسم الموقع
        const url = `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`;

        fetch(url)
          .then(response => response.json())
          .then(data => {
            if (data.address) {
              const locationName = data.address.city || data.address.town || data.address.village || "Unknown location";
              
              // تخزين اسم الموقع في localStorage
              localStorage.setItem("locationName", locationName);
              
              // عرض الموقع على الشاشة
              printMyLocation.innerText = `You are currently at: ${locationName}`;
            } else {
              printMyLocation.innerText = "Location not found.";
            }
          })
          .catch(error => {
            console.error("Error fetching location name:", error);
            printMyLocation.innerText = "Failed to get location name.";
          });
      }, (error) => {
        console.error("Error getting location:", error);
        printMyLocation.innerText = "Error retrieving location.";
      });
    } else {
      printMyLocation.innerText = "Geolocation is not supported by this browser.";
    }
  } else {
    // إذا كان الإذن قد تم منحه مسبقًا، فقط اعرض الموقع المخزن
    const cachedLocation = localStorage.getItem("locationName");

    if (cachedLocation) {
      if (printMyLocation.innerText.trim() === '') {
        
      printMyLocation.innerText = ` at: ${cachedLocation}`;
      }
      else if (printMyLocation.innerText !== '') {
        
      printMyLocation.innerText = ``;
      }
    } else {
      printMyLocation.innerText = "No location data available.";
    }
  }
});

// Text Formatting
  const textArea = document.getElementById('post-text');

  const fontFamily = document.getElementById('font-family');
  if (fontFamily) {
    fontFamily.addEventListener('change', function() {
      textArea.style.fontFamily = this.value;
      textArea.focus(); // Call refocus here
    });
  }

  const fontSize = document.getElementById('font-size');
  if (fontSize) {
    fontSize.addEventListener('change', function() {
      textArea.style.fontSize = this.value;
      textArea.focus(); // Call refocus here
    });
  }

      textAlign.forEach((icon, index )=> {
        let txtAlignArr = ['left', 'center','right'];
        icon.addEventListener('click', function() {
        textArea.style.textAlign = txtAlignArr[index];
        textAlign.forEach((btn, index) => {
        btn.classList.remove('active');
      });

    this.classList.add('active');
    textArea.focus(); // Call refocus here
    
  });
});

document.querySelectorAll('.font-style i').forEach((icon, index) => {
  icon.addEventListener('click', function () {
    const style = ['bold', 'italic', 'underline'];
    if (style[index] === 'bold') {
      textArea.style.fontWeight = textArea.style.fontWeight === 'bold' ? 'normal' : 'bold';
    } else if (style[index] === 'italic') {
      textArea.style.fontStyle = textArea.style.fontStyle === 'italic' ? 'normal' : 'italic';
    } else if (style[index] === 'underline') {
      textArea.style.textDecoration = textArea.style.textDecoration === 'underline' ? 'none' : 'underline';
    }
    this.classList.toggle('active');
    textArea.focus();
  });
});
// Change Font Color
if (fontColor) {
  fontColor.addEventListener('click', function () {
    const color = prompt('أدخل لون الخط (مثل: red, #FF0000):');
    if (color && isValidColor(color)) {
      textArea.style.color = color;
      fontColor.style.backGroundColor = '#1E90FF';
    } else {
      alert(`Invalid Color "${color}": is Not a Color`);
    }
    textArea.focus();
  });
}

const changeBackgroundColor = document.getElementById('change-background-color');
if (backGroundColor) {
  backGroundColor.addEventListener('click', function() {
    const color = prompt('أدخل لون الخلفية (مثل: yellow, #FFFF00):');
    if (color && isValidColor(color)) {
      textArea.style.background = color;
    } else {
      alert(`Invalid Background Color "${color}": is Not a Color`);
    }
    textArea.focus();
  });
};

function isValidColor(color) {
  const s = new Option().style;
  s.color = color;
  return s.color !== '';
}


// Event Listener for Close Button
closeBtn.addEventListener('click', () => {
  if (hasChanges) {
    confirmationModal.style.display = "block";
    overlay.style.display = "block";
  } else {
    closePostContainer();
  }
});

// Event Listener for Confirm Exit Button
confirmExitBtn.addEventListener('click', () => {
  closePostContainer();
});

// Event Listener for Cancel Exit Button
cancelExitBtn.addEventListener('click', () => {
  confirmationModal.style.display = "none";
  overlay.style.display = "none";
});

postBtn.addEventListener('click', () => {
  if (postText.value.trim() !== "") {
    simulatePost();
  }
});

// Text Editor
